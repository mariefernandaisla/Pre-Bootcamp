var "alturaNiño" = 100
function "MuestraSiElNiñoPuedeSubirALaMontañaRusa ()" {
    If (alturaNiño > 100) {
        console.log("¡Súbete, chico!");
        else {
            console.log("Lo siento, chico. Tal vez el próximo año")
        }
    }
}
